"use strict";
function i_applyFonts(parent) {
    if (currentFonts == null) {
        return;
    }
    emojiStyleElement = document.createElement("style");
    emojiStyleElement.type = "text/css";
    let cssContent = `--fontFamilyBase: ${currentFonts["fontFamily"]} !important;}`;
    let additionalImports = currentFonts["imports"];
    let fuiContent = `.fui-FluentProviderr0 {\n${cssContent}\n}`;
    let bodyContent = `* {\n${cssContent}\n}`;
    emojiStyleElement.innerHTML = `${additionalImports}\n${bodyContent}\n${fuiContent}`;
    console.log(emojiStyleElement.innerHTML);
    if (parent == null) {
        document.head.appendChild(emojiStyleElement);
        return emojiStyleElement;
    }
    else {
        parent.appendChild(emojiStyleElement);
        return emojiStyleElement;
    }
}
function i_updateIframes() {
    // Get the iframe element
    console.log("Updating iframes");
    const iframes = document.querySelectorAll('iframe'); // Replace with the actual iframe selector
    // Access the document inside the iframe
    iframes.forEach((iframe, index) => {
        if (iframe.contentWindow == null)
            return;
        const iframeDocument = iframe.contentDocument || iframe.contentWindow.document;
        const existingStyle = iframeDocument.querySelector("#fontsStyles");
        if (existingStyle != null)
            return;
        iframe.addEventListener("load", function () {
            setTimeout(function () {
                const head = iframeDocument.querySelectorAll("head");
                head.forEach((headEl, index) => {
                    const styleElement = applyFonts(headEl);
                    if (styleElement) {
                        styleElement.setAttribute("id", "#fontsStyles");
                    }
                    console.log("Created new styles under: ", headEl);
                    console.log("Iframe document: ", iframe);
                });
            }, 1000);
        });
    });
}
i_updateIframes();
